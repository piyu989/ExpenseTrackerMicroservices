package com.expenseService;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExpenseServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
